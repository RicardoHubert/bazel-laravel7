Project: /_project.yaml
Book: /_book.yaml

# Bazel Tutorial: Build an iOS App

This tutorial has been moved into the [bazelbuild/rules_apple](https://github.com/bazelbuild/rules_apple/blob/master/doc/tutorials/ios-app.md) repository.

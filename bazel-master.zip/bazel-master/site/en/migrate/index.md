Project: /_project.yaml
Book: /_book.yaml

# Migrating to Bazel

{% dynamic setvar source_file "site/en/migrate/index.md" %}
{% include "_buttons.html" %}

This page links to migration guides for Bazel.

*  [Maven](/migrate/maven)
*  [Xcode](/migrate/xcode)
*  [CocoaPods](/migrate/cocoapods)

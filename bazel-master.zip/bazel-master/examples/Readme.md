# Bazel examples (Deprecated)

This folder example is deprecated. In the future this folder will be deleted and all examples will be available in <https://github.com/bazelbuild/examples>.

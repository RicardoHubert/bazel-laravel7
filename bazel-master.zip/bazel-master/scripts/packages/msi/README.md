# Windows Installer Package (.msi) generator for Bazel

Usage:

```
powershell scripts\packages\msi\make_msi.ps1 bazel-0.28.2rc5-windows-x86_64.exe
```

Testing:

```
powershell scripts\packages\msi\make_msi_test.ps1
```
